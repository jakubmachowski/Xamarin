﻿namespace App4
{
    public interface IFileHelper
    {
        string GetLocalFilePath(string v);
    }
}